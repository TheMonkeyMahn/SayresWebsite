// This is my first mod, and I couldn't think of anything else to make
// Don't judge me

elements.cum = {
    name: "Cum",
    color: "#fafafa",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 80000,
    state: "liquid",
    density: 720,
    extraInfo: "A thick, foggy looking liquid that has cursed tadpoles in it.",
};

elements.deadCum = {
    name: "Dead Cum",
    color: "#f5ece1",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 85000,
    state: "liquid",
    density: 720,
    extraInfo: "A slightly thicker cum with dead sperm in it.",
};

elements.oldCum = {
    name: "Old Cum",
    color: "#c7b291",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 500000,
    state: "liquid",
    density: 720,
    extraInfo: "The forbidden putty.",
};

elements.bioenginneredCum = {
    name: "Bioengineered Cum",
    color: "#9ae69a",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 100,
    state: "liquid",
    density: 720,
    extraInfo: "This cum was made in a lab. It takes a milky green appearance and it is extremely runny.",
};

elements.ancientCum = {
    name: "Ancient Cum",
    color: "#2e281f",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 999999999,
    state: "liquid",
    density: 10000,
    extraInfo: "With a charcoal black color, this cum was found in the Pyramid Of Giza",
};

elements.poopyCum = {
    name: "Poopy Cum",
    color: "#543301",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 1000000,
    state: "liquid",
    density: 720,
    extraInfo: "Someone shat in it.",
};

elements.peeCum = {
    name: "Pissy Cum",
    color: "#f5e982",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 100000,
    state: "liquid",
    density: 720,
    extraInfo: "Someone pissed in it.",
};

elements.cumWater = {
    name: "Cum Water",
    color: "#cfe8e5",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 50000,
    state: "liquid",
    density: 720,
    extraInfo: "It's literally watery cum.",
};

elements.deadCumWater = {
    name: "Dead Cum Water",
    color: "#b0d1cd",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 55000,
    state: "liquid",
    density: 720,
    extraInfo: "It's dead cum water. Gross.",
};

elements.oldCumWater = {
    name: "Old Cum Water",
    color: "#fff7e6",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 50000,
    state: "liquid",
    density: 720,
    extraInfo: "It's old mildew smelling cum water."
};

elements.ancientCumWater = {
    name: "Ancient Cum Water",
    color: "#566e6b",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 10000,
    state: "liquid",
    density: 1000,
    extraInfo: "The ancient Greeks thought it would cure cancer.",
};

elements.preCumWater = {
    name: "Pre Cum Water",
    color: "#d8f2ef",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 1000,
    state: "liquid",
    density: 1000,
    extraInfo: "What the actual fuck.",
};

elements.preCum = {
    name: "Pre Cum",
    color: "#ffffff",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 1500,
    state: "liquid",
    density: 1500,
    extraInfo: "The stuff that comes out before the real thing.",
};

elements.bloodyCum = {
    name: "Bloody Cum",
    color: "#ff9494",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 1500,
    state: "liquid",
    density: 1500,
    extraInfo: "Ouch.",
};


elements.goldenCum = {
    name: "The Cum Of Life",
    color: "#ffd700",
    behavior: behaviors.LIQUID,
    category: "cum",
    viscosity: 0.0000000000000000000000000000000000000000000000001,
    state: "liquid",
    density: 99999999999999999999999999999999999999999999999999999,
    extraInfo: "Extremely runny and unfathomably heavy.",
};
