// This is my first mod, and I couldn't think of anything else to make
// Don't judge me

elements.cum = {
    color: "#fafafa",
    behavior: behaviors.LIQUID,
    category: "sex",
    viscosity: 100000,
    state: "liquid",
    density: 720,
};

elements.lube = {
    color: "#cceeff",
    behavior: behaviors.LIQUID,
    category: "sex",
    viscosity: 300000,
    state: "liquid",
    density: 800
};



elements.human.name = "hooker"